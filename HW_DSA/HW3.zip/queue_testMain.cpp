﻿#include "queue.h" 
#include <stdio.h> 
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#define MAX_LEN 20
#define MAX_SIZE 100
#define GRADE1 "c:\\data\\grade1.txt"
#define GRADE2 "c:\\data\\grade2.txt"
#define GRADE3 "c:\\data\\grade3.txt"
#define WIN "c:\\data\\win.txt"

void myFlush(); 
void lottery(Queue*, Queue*, Queue* ,char *);
void queueFileload(Queue *,char *);
void myDelete(Queue *); 
void saveFile(Queue *qPtr, DataType *Data, FILE *fp);
void phone(DataType *Data);
int random(int num);
//--------------------------------------------------------------------------------
//   main() 
//--------------------------------------------------------------------------------
int main() 
{ 
	int i;
	Queue que1; /* 큐생성*/ 
	initQueue(&que1,MAX_SIZE); /* 크기가 100인 큐 생성 및 초기화*/ 
	Queue que2;
	initQueue(&que2, MAX_SIZE);
	Queue que3;
	initQueue(&que3, MAX_SIZE);
	Queue res;
	initQueue(&res, MAX_SIZE);

	srand((unsigned int)time(NULL));
	
	queueFileload(&que1, GRADE1);
	queueFileload(&que2, GRADE2);
	queueFileload(&que3, GRADE3);
	lottery(&que1,&que2,&que3,WIN);
	queueFileload(&res, WIN);
	
	printf("\n[ NO.\t당첨자명\t%10s\t\t%8s ]\n\n","주민번호","연락처");
	for (i = 0; i < res.rear; i++) {
		printf("%3d.", i + 1);
		printInt(&res.queue[i]);
	}
	printf("\n");

	destroyQueue(&que1); 
	return 0; 
} 

void lottery(Queue *qPtr, Queue*qPtr2, Queue*qPtr3, char *grade)		// 추첨하는 함수
{
	int num,rand;
	int i,j;
	DataType getData,resData;
	FILE *fp;
	fp = fopen(grade, "wt");
	assert(fp != NULL);
	printf("추첨자 명수를 입력하세요 : ");
	scanf("%d", &num);
	
	if (num <= qPtr->rear) {
		for (i = 0; i < num; i++) {
			rand = random(qPtr->rear - i);
			for (j = 0; j < rand; j++) {
				dequeue(qPtr, &getData);
				enqueue(qPtr, getData);
			}
			saveFile(qPtr, &resData, fp);
		}
	}
	else if (num > qPtr->rear && num <= (qPtr->rear + qPtr2->rear)) {
		for (i = 0; i < qPtr->rear; i++)
			saveFile(qPtr, &getData, fp);
		for (i = 0; i < num - qPtr->rear; i++) {
			rand = random(qPtr2->rear - i);
			for (j = 0; j < rand; j++) {
				dequeue(qPtr2, &getData);
				enqueue(qPtr2, getData);
			}
			saveFile(qPtr2, &resData, fp);
		}
	}
	else if (num > (qPtr->rear + qPtr2->rear) && num <= (qPtr->rear + qPtr2->rear + qPtr3->rear)) {
		for (i = 0; i < qPtr->rear; i++)
			saveFile(qPtr, &getData, fp);
		for (i = 0; i < qPtr2->rear; i++)
			saveFile(qPtr2, &getData, fp);
		for (i = 0; i < num - (qPtr->rear + qPtr2->rear); i++) {
			rand = random(qPtr3->rear - i);
			for (j = 0; j < rand; j++) {
				dequeue(qPtr3, &getData);
				enqueue(qPtr3, getData);
			}
			saveFile(qPtr3, &resData, fp);
		}
	}
	else
		printf("\n*** 총 인원은 %d 명입니다. ***\n\n",qPtr->rear+ qPtr2->rear+ qPtr3->rear);
	fclose(fp);
	return;
}

void queueFileload(Queue *qPtr,char *grade) // 파일에서 받아와서 queue에 저장하는 함수
{
	int i = 0;
	int len;
	DataType inData[MAX_SIZE];
	FILE *fp;
	fp = fopen(grade, "rt");
	assert(fp != NULL);
	
	while (fgets(inData[i].name, MAX_LEN, fp) != NULL)
	{
		len = strlen(inData[i].name);
		inData[i].name[len - 1] = '\0';
		fscanf(fp, "%s ", inData[i].birth);
		fscanf(fp, "%s ", inData[i].phone);
		enqueue(qPtr, inData[i]);
		i++;
	}
	fclose(fp);
	return;
}

/*------------------------------------------------------------------------------------------------------------ 
함수명 및 기능: myFlush() - 입력버퍼 지우기 
전달인자: 없음 
리턴값: 없음 
------------------------------------------------------------------------------------------------------------*/ 
void myFlush() 
{ 
	while(getchar()!='\n'){ ; } 
}

int random(int num)
{
	int res;
	res = rand() % num;
	return res;
}

void saveFile(Queue *qPtr, DataType *Data, FILE *fp)
{
	dequeue(qPtr, Data);
	fputs(Data->name, fp);
	fputs("\n", fp);
	strcat(Data->birth, "-*******");
	fputs(Data->birth, fp);
	fputs("\n", fp);
	phone(Data);
	fputs(Data->phone, fp);
	fputs("\n", fp);
	return;
}

void phone(DataType *Data)
{
	int i;
	int len = strlen(Data->phone);
	for (i = len - 1; i >= len - 4; i--)
		Data->phone[i] = '*';
	return;
}

void printInt(DataType *p)
{
	if(strlen(p->name)>7)
		printf("\t%s\t%s\t\t%s\n", p->name,p->birth, p->phone);
	else
		printf("\t%s\t\t%s\t\t%s\n", p->name, p->birth, p->phone);
}