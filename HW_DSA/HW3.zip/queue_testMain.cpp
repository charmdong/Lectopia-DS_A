﻿#include "queue.h" 
#include <stdio.h> 
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#define MAX_LEN 20
#define MAX_SIZE 100
#define GRADE1 "c:\\data\\grade1.txt"
#define GRADE2 "c:\\data\\grade2.txt"
#define GRADE3 "c:\\data\\grade3.txt"
#define WIN "c:\\data\\win.txt"
#define TRUE 1
#define FALSE 0

void myFlush(); 
int lottery(Queue*,char *);
void queueFileload(Queue *,char *);
void myDelete(Queue *); 
void saveFile(Queue *qPtr, DataType *Data, FILE *fp);
void phone(DataType *Data);
int random(int num);
//--------------------------------------------------------------------------------
//   main() 
//--------------------------------------------------------------------------------
int main() 
{ 
	int i;
	Queue que; /* 큐생성*/ 
	initQueue(&que,MAX_SIZE); /* 크기가 100인 큐 생성 및 초기화*/ 
	

	srand((unsigned int)time(NULL));
	
	queueFileload(&que, GRADE1);
	
	if (lottery(&que, WIN)){
		initQueue(&que, MAX_SIZE);
		queueFileload(&que, WIN);
		printf("\n[ NO.\t당첨자명\t%10s\t\t%8s ]\n\n", "주민번호", "연락처");
		for (i = 0; i < que.rear; i++) {
			printf("%3d.", i + 1);
			printInt(&que.queue[i]);
		}
		printf("\n");
	}
	destroyQueue(&que); 
	return 0; 
} 

int lottery(Queue *qPtr, char *grade)		// 추첨하는 함수
{
	int num,rand;
	int i,j;
	DataType getData,resData;
	FILE *fp;
	fp = fopen(grade, "wt");
	assert(fp != NULL);
	printf("추첨자 명수를 입력하세요 : ");
	scanf("%d", &num);
	
	if (num < qPtr->rear) {	// 당첨자 인원이 grade1명단 수보다 작은 경우
		for (i = 0; i < num; i++) {
			rand = random(qPtr->rear - i);
			for (j = 0; j < rand; j++) {
				dequeue(qPtr, &getData);
				enqueue(qPtr, getData);
			}
			saveFile(qPtr, &resData, fp);
		}
	}
	else{	                           //grade1 명단 수보다 크거나 같은 경우
		num -= qPtr->rear;
		
		for (i = 0; i < qPtr->rear; i++)
			saveFile(qPtr, &getData, fp);
		
		initQueue(qPtr,MAX_SIZE);
		queueFileload(qPtr, GRADE2);
		
		if (num < qPtr->rear) {		//grade2 명단 수보다 작은 경우
			for (i = 0; i < num; i++) {
				rand = random(qPtr->rear - i);
				for (j = 0; j < rand; j++) {
					dequeue(qPtr, &getData);
					enqueue(qPtr, getData);
				}
				saveFile(qPtr, &resData, fp);
			}
		}
		else		                           // grade2 명단 수보다 많거나 같은 경우
		{
			num -= qPtr->rear;				// num = num - qPtr->rear - qPtr2->rear

			for (i = 0; i < qPtr->rear; i++)
				saveFile(qPtr, &getData, fp);

			initQueue(qPtr, MAX_SIZE);
			queueFileload(qPtr, GRADE3);

			if (num < qPtr->rear) {
				for (i = 0; i < num; i++) {
					rand = random(qPtr->rear - i);
					for (j = 0; j < rand; j++) {
						dequeue(qPtr, &getData);
						enqueue(qPtr, getData);
					}
					saveFile(qPtr, &resData, fp);
				}
			}
			else if (num == qPtr->rear) {
				for (i = 0; i < qPtr->rear; i++)
					saveFile(qPtr, &getData, fp);
			}
			else {
				printf("\n *** 총 인원을 넘는 수입니다 ***\n\n");
				return FALSE;
			}
		}
	}

	fclose(fp);
	return TRUE;
}

void queueFileload(Queue *qPtr,char *grade) // 파일에서 받아와서 queue에 저장하는 함수
{
	int i = 0;
	int len;
	DataType inData[MAX_SIZE];
	FILE *fp;
	fp = fopen(grade, "rt");
	assert(fp != NULL);
	
	while (fgets(inData[i].name, MAX_LEN, fp) != NULL)
	{
		len = strlen(inData[i].name);
		inData[i].name[len - 1] = '\0';
		fscanf(fp, "%s ", inData[i].birth);
		fscanf(fp, "%s ", inData[i].phone);
		enqueue(qPtr, inData[i]);
		i++;
	}
	fclose(fp);
	return;
}

/*------------------------------------------------------------------------------------------------------------ 
함수명 및 기능: myFlush() - 입력버퍼 지우기 
전달인자: 없음 
리턴값: 없음 
------------------------------------------------------------------------------------------------------------*/ 
void myFlush() 
{ 
	while(getchar()!='\n'){ ; } 
}

int random(int num)
{
	int res;
	res = rand() % num;
	return res;
}

void saveFile(Queue *qPtr, DataType *Data, FILE *fp)
{
	dequeue(qPtr, Data);
	fputs(Data->name, fp);
	fputs("\n", fp);
	strcat(Data->birth, "-*******");
	fputs(Data->birth, fp);
	fputs("\n", fp);
	phone(Data);
	fputs(Data->phone, fp);
	fputs("\n", fp);
	return;
}

void phone(DataType *Data)
{
	int i;
	int len = strlen(Data->phone);
	for (i = len - 1; i >= len - 4; i--)
		Data->phone[i] = '*';
	return;
}

void printInt(DataType *p)
{
	if(strlen(p->name)>7)
		printf("\t%s\t%s\t\t%s\n", p->name,p->birth, p->phone);
	else
		printf("\t%s\t\t%s\t\t%s\n", p->name, p->birth, p->phone);
}